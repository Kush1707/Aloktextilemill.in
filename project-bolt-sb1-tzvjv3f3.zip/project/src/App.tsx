import React from 'react';
import { Printer, Factory, Phone, Mail, MapPin, ChevronRight, ToyBrick as Fabric, Palette, Image, MessageSquare } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <header className="relative h-screen">
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&q=80"
            alt="Textile Printing"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50"></div>
        </div>
        
        <nav className="relative z-10 bg-white/10 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              <div className="flex items-center">
                <Printer className="h-8 w-8 text-white" />
                <span className="ml-2 text-2xl font-bold text-white">ALOK TEXTILE MILL</span>
              </div>
              <div className="hidden md:block">
                <div className="flex items-center space-x-8">
                  <a href="#services" className="text-white hover:text-gray-200">Services</a>
                  <a href="#gallery" className="text-white hover:text-gray-200">Gallery</a>
                  <a href="#about" className="text-white hover:text-gray-200">About</a>
                  <a href="#contact" className="text-white hover:text-gray-200">Contact</a>
                </div>
              </div>
            </div>
          </div>
        </nav>

        <div className="relative z-10 flex items-center justify-center h-[calc(100vh-5rem)]">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 max-w-4xl mx-auto leading-tight">
              Leading Digital Textile Printing Solutions for Modern Fabric Innovation
            </h1>
            <a 
              href="#contact"
              className="inline-flex items-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              Get a Quote <ChevronRight className="ml-2 h-5 w-5" />
            </a>
          </div>
        </div>
      </header>

      {/* Services Section */}
      <section id="services" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Services</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Fabric, title: 'Cotton Printing', desc: 'High-quality digital printing on cotton fabrics' },
              { icon: Palette, title: 'Silk Printing', desc: 'Vibrant and detailed prints on silk materials' },
              { icon: Image, title: 'Linen Printing', desc: 'Precise printing on linen fabrics' },
              { icon: Printer, title: 'Polyester Printing', desc: 'Durable prints on polyester materials' },
              { icon: Factory, title: 'Hosiery Printing', desc: 'Specialized printing for hosiery items' },
              { icon: MessageSquare, title: 'Custom Solutions', desc: 'Tailored printing solutions for your needs' },
            ].map((service, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-md">
                <service.icon className="h-12 w-12 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-gray-600">{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Our Gallery</h2>
          
          <div className="mb-16">
            <h3 className="text-2xl font-semibold mb-8">Our Factory</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="aspect-w-16 aspect-h-9">
                <img src="/factory/factory1.jpg" alt="Factory Front View" className="rounded-lg shadow-md object-cover w-full h-64" />
              </div>
              <div className="aspect-w-16 aspect-h-9">
                <img src="/factory/factory2.jpg" alt="Factory Processing Area" className="rounded-lg shadow-md object-cover w-full h-64" />
              </div>
              <div className="aspect-w-16 aspect-h-9">
                <img src="/factory/factory3.jpg" alt="Factory Side View" className="rounded-lg shadow-md object-cover w-full h-64" />
              </div>
              <div className="lg:col-span-2 aspect-w-16 aspect-h-9">
                <img src="/factory/factory4.jpg" alt="Factory Panoramic View" className="rounded-lg shadow-md object-cover w-full h-64" />
              </div>
              <div className="aspect-w-16 aspect-h-9">
                <img src="/factory/factory5.jpg" alt="Factory Full View" className="rounded-lg shadow-md object-cover w-full h-64" />
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-semibold mb-8">Printed Designs</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <img src="https://images.unsplash.com/photo-1606760227091-3dd870d97f1d?auto=format&fit=crop&q=80" alt="Printed Design" className="rounded-lg shadow-md h-64 w-full object-cover" />
              <img src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&q=80" alt="Printed Design" className="rounded-lg shadow-md h-64 w-full object-cover" />
              <img src="https://images.unsplash.com/photo-1459156212016-c812468e2115?auto=format&fit=crop&q=80" alt="Printed Design" className="rounded-lg shadow-md h-64 w-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">About Alok Textile Mill</h2>
              <p className="text-gray-600 mb-4">
                At Alok Textile Mill, we combine cutting-edge digital printing technology with decades of textile expertise to deliver exceptional printing solutions for the modern textile industry.
              </p>
              <p className="text-gray-600 mb-4">
                Our state-of-the-art facility is equipped with the latest digital printing machinery, allowing us to provide high-quality prints on a wide range of fabrics while maintaining consistent quality and quick turnaround times.
              </p>
              <p className="text-gray-600">
                We pride ourselves on our commitment to innovation, sustainability, and customer satisfaction, making us a trusted partner for all your textile printing needs.
              </p>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&q=80"
                alt="About Us"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Contact Us</h2>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-xl font-semibold mb-6">Get in Touch</h3>
              <form className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                  <input
                    type="text"
                    id="name"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    type="email"
                    id="email"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700">Message</label>
                  <textarea
                    id="message"
                    rows={4}
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
                >
                  Send Message
                </button>
              </form>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-6">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <MapPin className="h-6 w-6 text-blue-600 mr-3" />
                  <p className="text-gray-600">123 Textile Street, Industrial Area, City, Country</p>
                </div>
                <div className="flex items-center">
                  <Phone className="h-6 w-6 text-blue-600 mr-3" />
                  <p className="text-gray-600">+1 234 567 890</p>
                </div>
                <div className="flex items-center">
                  <Mail className="h-6 w-6 text-blue-600 mr-3" />
                  <p className="text-gray-600">info@aloktextilemill.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center mb-4 md:mb-0">
              <Printer className="h-8 w-8" />
              <span className="ml-2 text-xl font-bold">ALOK TEXTILE MILL</span>
            </div>
            <div className="text-center md:text-right">
              <p>&copy; {new Date().getFullYear()} Alok Textile Mill. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;